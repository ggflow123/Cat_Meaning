// takes a default import, and default export it 😊
export { default } from "./src";
