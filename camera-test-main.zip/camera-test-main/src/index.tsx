import React, { FC } from "react";

import Home from "./scenes/home";

const App: FC = () => <Home />;

export default App;
